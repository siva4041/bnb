=========================
| NULLED BY GPLPlus.COM |
=========================

1. Install and activate web template -> (\woodmart\ )
2. Go to "WoodMart" -> "Theme license" and enter license key: NULLED-BY-GPLPlus.COM
3. Install NULLED Plugins -> (\Plugins\ )
   *License Key for Slider Revolution: 5u00000b-78e1-4oa4-ganja-3parker2dfd390

=========================
| NULLED BY GPLPlus.COM |
=========================