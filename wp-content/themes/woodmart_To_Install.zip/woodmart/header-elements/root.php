<div class="whb-main-header">
	<?php echo $children;?>
</div>
